document.addEventListener('DOMContentLoaded', function () {
    const simBtn = document.getElementById('simBtn');
    const naoBtn = document.getElementById('naoBtn');
    const respostaContainer = document.getElementById('resposta-container');
    const respostaTexto = document.getElementById('resposta-texto');
    const imagemInicial = document.getElementById('imagem-inicial');
    const respostaImagem = document.getElementById('resposta-imagem');

    simBtn.addEventListener('click', function () {
        respostaTexto.textContent = "que bom meu tchuio 😊😊😊 te amo infinitamente pra sempre amor";
        respostaContainer.classList.remove('oculto');
        respostaImagem.src = "imagens/sim.jpg";
        imagemInicial.style.display = "none";
        document.body.style.backgroundColor = "#ffc0cb";
        document.querySelector(".container").style.backgroundColor = "#fdfdfd";

    });

    naoBtn.addEventListener('click', function () {
        respostaTexto.textContent = "pq meu amor 😭😭😭 me responde no zap amor, vo te enche de carinho nene";
        respostaContainer.classList.remove('oculto');
        respostaImagem.src = "imagens/nao.png";
        imagemInicial.style.display = "none";
        document.body.style.backgroundColor = "#0046b8";
        document.querySelector(".container").style.backgroundColor = "#e0e0e0";
    });
});